
# Introduction to code base
This codebase is to run and reproduce the monocular vehicle estimation 
MSc disseration by candidate HMZD2 from UCL. It contains three main directories:

- Frameworks: this contains all the code and checkpoint for the models used.
- World Coordinate Code: this contains the code to run the world coordinate vehicle estimation.
it contains 3 notebooks for vehicle estimation, and one for COLMAP. 
- Camera Coordinate Code: this contains the code to run the camera coordinate vehicle estimation.
it contains 3 notebooks for vehicle estimation.

# Frameworks
Create a directory called `Frameworks` and download the following repositories:
- [SpatialTracker](https://github.com/henry123-boy/SpaTracker): 
- [COLMAP](https://colmap.github.io/)
- [DepthAnything](https://github.com/DepthAnything/Depth-Anything-V2/tree/main/metric_depth)
- [ZoeDepth](https://github.com/isl-org/ZoeDepth)
- [co-tracker](https://github.com/facebookresearch/co-tracker)

Use their corresponding instructions to install the dependencies and model paths. 
# World Coordinate Code
This contains for the three frameworks the corresponding notebooks. Also, 
the results are found here including a notebook to plot the results and 
analyse the error. These notebooks are also well documented and explained 
for each function. 

# Camera Coordinate Code
This contains for the three frameworks the corresponding notebooks. Also,
the results are found here including a notebook to plot the results and
analyse the error.

# Remarks
- The code contains an 'out_dir' variable that needs to be changed to the
desired output directory.
- The code was run on a Google Colab Pro instance with a A100 GPU.